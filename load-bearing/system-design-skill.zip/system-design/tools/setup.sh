#!/bin/bash
# Installs puppeteer-core next to the tools, once. Uses the installed Google Chrome.
cd "$(dirname "$0")"
[ -d node_modules/puppeteer-core ] || npm install --silent puppeteer-core@23 >/dev/null
[ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ] || echo "Google Chrome not found at /Applications; set CHROME=/path/to/chrome"
echo ready
