// node svgx.mjs <guide.html> <outDir> [skipId,...]
// Writes each figure's SVG (white background) as <id>.svg for use as <img> in a site lesson. Prints [id, title] pairs.
import puppeteer from 'puppeteer-core'; import fs from 'node:fs'; import path from 'node:path'
const [src, out, skip = ''] = process.argv.slice(2); const skipIds = skip.split(',')
const b = await puppeteer.launch({ executablePath: process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: 'new' }); const p = await b.newPage()
await p.goto('file://' + path.resolve(src), { waitUntil: 'load' })
const figs = await p.evaluate(() => [...document.querySelectorAll('figure svg')].map(s => { const c = s.cloneNode(true); c.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); const vb = c.getAttribute('viewBox').split(' '); c.setAttribute('width', vb[2]); c.setAttribute('height', vb[3]); c.removeAttribute('id')
  const r = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); r.setAttribute('width', '100%'); r.setAttribute('height', '100%'); r.setAttribute('fill', '#ffffff'); c.insertBefore(r, c.firstChild)
  return { id: s.id, title: s.closest('figure').querySelector('.ft').textContent.replace(/^Figure \d+ · /, ''), svg: c.outerHTML } }))
fs.mkdirSync(out, { recursive: true })
for (const f of figs) if (!skipIds.includes(f.id)) fs.writeFileSync(`${out}/${f.id}.svg`, f.svg)
console.log(JSON.stringify(figs.map(f => [f.id, f.title])))
await b.close()
