// node snapshot.mjs <bookDir> <snapDir> [file ...]
// No files: builds a full publish snapshot of the book (src without mp4s, local-video Reel blocks removed).
// With files (paths relative to bookDir): copies only those into an existing snapshot, so other sessions' unreviewed lessons stay unpublished.
import fs from 'node:fs'; import path from 'node:path'
const [book, snap, ...files] = process.argv.slice(2)
const strip = (code) => code
  .replace(/^import (\w+) from '[^']+\.mp4'\s*$/gm, "const $1 = ''")
  .replace(/<H2>[^<]*<\/H2>\s*<p>[\s\S]*?<\/p>\s*<Reel[\s\S]*?\/>/g, '')
  .replace(/<Reel[\s\S]*?\/>/g, '')
const copy = (rel) => { const from = path.join(book, rel), to = path.join(snap, rel); fs.mkdirSync(path.dirname(to), { recursive: true })
  if (/\.tsx?$/.test(rel)) { const c = fs.readFileSync(from, 'utf8'); fs.writeFileSync(to, c.includes('.mp4') ? strip(c) : c) } else fs.copyFileSync(from, to) }
const walk = (d) => fs.readdirSync(path.join(book, d), { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)])
if (files.length) { files.forEach(copy); console.log(`copied ${files.length} file(s)`) }
else {
  fs.mkdirSync(snap, { recursive: true })
  const all = walk('src').filter(f => !/\.(mp4|mov|webm)$/.test(f)); all.forEach(copy)
  for (const f of ['index.html', 'package.json', 'tsconfig.json']) if (fs.existsSync(path.join(book, f))) copy(f)
  fs.writeFileSync(path.join(snap, 'vite.config.ts'), "import { defineConfig } from 'vite'\nimport react from '@vitejs/plugin-react'\n\nexport default defineConfig({ base: '/load-bearing/', plugins: [react()] })\n")
  const nm = path.join(snap, 'node_modules'); if (!fs.existsSync(nm)) fs.symlinkSync(path.join(book, 'node_modules'), nm)
  const left = walk('src').filter(f => /\.tsx?$/.test(f)).filter(f => fs.readFileSync(path.join(snap, f), 'utf8').match(/\.mp4'|<Reel/))
  console.log(`snapshot: ${all.length} files${left.length ? '; still referencing video: ' + left.join(', ') : ''}`)
}
