// node render.mjs <guide.html> <out.pdf> [pngDir]
// Prints page errors, figure count, page count, and any SVG text that runs outside its viewBox.
import puppeteer from 'puppeteer-core'; import fs from 'node:fs'; import path from 'node:path'
const [src, out, pngDir] = process.argv.slice(2)
const b = await puppeteer.launch({ executablePath: process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: 'new' })
const p = await b.newPage(); const errs = []
p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()))
await p.setViewport({ width: 1000, height: 1200, deviceScaleFactor: 1.5 })
await p.goto('file://' + path.resolve(src), { waitUntil: 'load' })
const report = await p.evaluate(() => {
  const out = [], empty = []
  for (const s of document.querySelectorAll('figure svg')) {
    if (!s.childElementCount) empty.push(s.id)
    const vb = s.viewBox.baseVal
    for (const t of s.querySelectorAll('text')) { const r = t.getBBox(); if (r.x < vb.x - 1 || r.y < vb.y - 1 || r.x + r.width > vb.x + vb.width + 1 || r.y + r.height > vb.y + vb.height + 1) out.push(`${s.id}: "${t.textContent.slice(0, 40)}"`) }
  }
  return { figures: document.querySelectorAll('figure svg').length, empty, clipped: out, emDash: (document.body.innerText.match(/—/g) || []).length }
})
if (pngDir) { fs.mkdirSync(pngDir, { recursive: true }); for (const id of await p.$$eval('figure svg[id]', a => a.map(s => s.id))) { const f = await p.$(`#${id}`); await (await f.evaluateHandle(n => n.closest('figure'))).asElement().screenshot({ path: `${pngDir}/${id}.png` }) } }
await p.pdf({ path: out, format: 'Letter', printBackground: true, preferCSSPageSize: true })
const pages = (fs.readFileSync(out, 'latin1').match(/\/Type\s*\/Page[^s]/g) || []).length
console.log(JSON.stringify({ errors: errs, pages, ...report }, null, 1))
await b.close()
