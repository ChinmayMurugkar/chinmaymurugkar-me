# Guide to site lesson, and publishing

The worked example is `example/bp-chat.tsx`, live at https://www.chinmaymurugkar.com/load-bearing/#/lesson/bp-chat.

## 1. Export the figures
```bash
mkdir -p $BOOK/src/content/blueprints/<id>
node $SKILL/tools/svgx.mjs $W/guide.html $BOOK/src/content/blueprints/<id> final
```
It prints `[id, title]` pairs to use as figure titles. Skip the final architecture figure (`final`), because the lesson rebuilds it as an interactive `SystemDiagram` with steps.

## 2. Write `src/content/blueprints/<id>.tsx`
Copy the structure of `bp-chat.tsx`:
- `import x from './<id>/x.svg'` for each figure. Use the local `Pic` helper (a `Figure` around a white div with an `img`) and the `Table` helper (`.fig > .table-scroll > table.matrix`).
- `meta`: `summary`, `minutes` (about 30 to 40), and `buildsOn` (the lesson ids from the guide's concept map).
- The guide's parts become `H2` sections in the same order. `.box l7` becomes `L7Lens`, `.box bad` becomes `FailureMode(title, trigger, symptom, contain)`, the levels part becomes `LevelCompare` plus a table, and curveballs become three `Probe`s. Add `Takeaways` and `Sources`.
- Rebuild the final design as `SystemDiagram`: width about 1200, 12 to 15 nodes, and one `step` per stage of the main path. Keep labels under about 14 characters at w=164.
- Add a DECISIONS table: decision → linked Load Bearing lessons → DDIA chapter. This is the "where each decision comes from" section.
- Put each `pre` block in `style={{ overflowX: 'auto' }}` so a phone never scrolls sideways.

## 3. Check
```bash
cd $BOOK && npx tsc --noEmit
npx vite --port 5199 &   # if no dev server is running
BASE=http://localhost:5199/ npm run check:lessons -- blueprints
npm run check:links -- src/content/blueprints
```
Fix "a line crosses <node>" by changing `fromSide`, `toSide` or `fromOffset`. You can ignore a 404 for `/_vercel/insights/script.js`, because it only happens on the dev server.

## 4. Publish (only when asked)
To keep other sessions' unreviewed lessons offline, publish the changed files only:
```bash
SNAP=<scratchpad>/publish
[ -d $SNAP/src ] || node $SKILL/tools/snapshot.mjs $BOOK $SNAP          # full snapshot, first time in a session
node $SKILL/tools/snapshot.mjs $BOOK $SNAP src/content/blueprints/<id>.tsx src/content/blueprints/<id>/*.svg   # changed files only (paths relative to BOOK)
cd $SNAP && npx vite build --outDir dist --emptyOutDir
rsync -a --delete $SNAP/dist/ $SITE/load-bearing/
cd $SITE && git add load-bearing && git commit -m "Load Bearing: <what changed>" && git push origin main
```
- The relative paths only work if you `cd $BOOK` first. Expand the globs there.
- A fresh full snapshot copies every lesson in the book. So when the snapshot is new, build it from the last published state: run `git -C $SITE log -3 --stat -- load-bearing` and confirm that the user wants every written lesson to go live. Otherwise, copy only the files for this change.
- Vercel deploys in about 15 seconds. To verify, fetch `https://www.chinmaymurugkar.com/load-bearing/`, find the lesson's asset name in `dist/assets/<id>-*.js`, and `curl` that asset to check that it contains a unique string from the lesson.
- End commit messages with the attribution line the session's system reminder gives.
