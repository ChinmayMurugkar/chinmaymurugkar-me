---
name: system-design
description: Writes a Load Bearing L7 system design guide as a diagram-heavy PDF (a chat system, a metrics platform, a ride-hailing app and so on). It follows the interview delivery framework, builds the design one requirement at a time with product-named boxes, then adds the L7 layer (contracts, deciding numbers, failure modes, degradation, evolution, cost, ownership, levels) and links every decision to Load Bearing lessons, DDIA, Alex Xu and Hello Interview without copying them. It can also turn the guide into a site lesson, publish it to chinmaymurugkar.com/load-bearing, or hand it to a video skill. Use when the user runs /system-design or asks for a system design guide, an "at L7" PDF, or an interview problem write-up in the house style.
---

# /system-design

The argument is free text: **subject**, **where to store**, and **what to do after**. Examples:
- `/system-design chat system`
- `/system-design ride hailing like Uber, save to ~/Desktop/guides, then add it to the site as bp-ride-hailing and publish`
- `/system-design notification platform; after: make a neonboard video`

Read the argument this way:
- **Subject**: the system to design. If it's missing, ask for it and nothing else.
- **Store**: a folder or a file path. Default: `~/Downloads/<Subject> at L7 - Chinmay Murugkar.pdf`. Never overwrite an existing file. Add ` (v2)` instead.
- **After**: zero or more of the actions in "After the PDF" below. If none is given, stop after the PDF and offer them in one line.

```bash
SKILL=~/.claude/skills/system-design          # this folder
BOOK=~/Desktop/Chinmay/workspace/interviewPrep/system-design/chinmay-systemdesign-book
SITE=~/Desktop/Chinmay/workspace/chinmaymurugkar-website
bash $SKILL/tools/setup.sh                    # puppeteer-core once; uses installed Chrome
```
Work in the session scratchpad: `W=<scratchpad>/<slug>`, then `cp $SKILL/template/starter.html $W/guide.html`.

## What's in this folder
- `template/starter.html`: the CSS (Letter pages, serif headings, `.box l7|warn|bad|ok`, `.calc`, `.say`, `.qa`, `.pill`, figures), a cover and the SVG helpers. Fill in the `__PLACEHOLDERS__`.
- `example/chat-guide.html`: the finished chat guide (29 pages, 23 figures). It's the reference for tone, depth, section order and figure style. Read it before writing the first guide in a session. Reuse its patterns, not its words.
- `example/bp-chat.tsx`: the same guide turned into a site lesson.
- `tools/render.mjs`: renders HTML to a PDF and optional per-figure PNGs. It prints JS errors, page count, empty figures, SVG text that runs outside its viewBox, and em-dash count.
- `tools/svgx.mjs`: exports each figure as a standalone SVG for a site lesson.
- `tools/snapshot.mjs`: builds the publish snapshot of the book for the website.
- `reference/site-lesson.md`: converting the guide to a lesson, and the publish flow.

## The shape of every guide (the order is fixed)
Use the delivery framework interviewers know (Hello Interview's order, and Xu chapter 3's four steps), then add the L7 layer. Target 25 to 30 pages, 20 to 25 figures and about 14 parts. Each part starts on a new page (`<section class="part">` with an eyebrow `N · ...`, an `h2` and a `.lead`).

1. **Cover**: eyebrow "Load Bearing · Interview problem guide", "Designing X at L7", a one-paragraph sub, the byline "by Chinmay Murugkar", a companion line naming chinmaymurugkar.com/load-bearing (illustrative numbers, product names are examples, month and year), and a TOC.
2. **The framework and what changes at L7**: a figure of the steps, with each step's L5/L6/L7 difference. Say who steers at each level.
3. **Requirements**: functional in and out of scope (a scope figure). Then non-functional requirements written as **contracts with numbers**: p99 latency, durability, ordering, availability per path, freshness. Each contract names the decision it forces.
4. **Numbers that decide the design**: only numbers that change a choice. Show the math as a teaching dashboard: `.calc` lines and `tile()` figures (`500M × 40 = 20B / day`). No count-up animations. Label every invented number as illustrative.
5. **Core entities and the API**: an entity figure (`erbox`), and API calls as `code` or `pre`, including the realtime and idempotency fields.
6. **High-level design, one requirement at a time**: a figure per step (hld1..hld4). New boxes are highlighted. After each step, a numbered walk-through and a **"What's wrong with it:"** paragraph that forces the next step. End with the whole design: one large figure with numbered steps along the main path.
7. **Deep dives** (3 to 5, chosen for this subject, each its own part): the mechanism with a figure, then the options compared (`table`, L7 column `class="l7"`), a recommendation, and a `.box bad` failure mode (trigger, symptom, containment).
8. **Failures, degradation, evolution and ownership**: a failure table figure (fault, symptom, containment, coloured green or yellow), a degradation ladder (what gets shed first, what is never shed), evolution steps each with its **trigger**, and cost and team ownership.
9. **What each level is expected to show**: a levels figure and a table from mid-level to principal.
10. **Curveballs** (`.qa`), a **scorecard** to grade your own answer, and **corrections to common notes** on this problem, where popular answers are wrong or out of date. Cite a source for each correction.
11. **Where each concept is taught in Load Bearing**: map each decision to lesson ids from `$BOOK/src/curriculum.ts`. Mark lessons that exist as `pill w` "written" and the rest `pill p` "planned" (check whether `$BOOK/src/content/**/<id>.tsx` exists). Add a decisions table: decision → Load Bearing lessons → DDIA chapter → Xu chapter or Hello Interview, if they cover it.
12. **Sources**: primary sources (engineering blogs, papers, RFCs, docs) for every claim about a real system.

## Content rules
- **The goal is L7.** For every major choice, say how it fails, what it costs, who must change, and when not to build it. Use `.box l7` for the moves a staff or principal candidate makes, and `.say` for one sentence to say out loud.
- **Best of all worlds, copied from none.** Combine Load Bearing lessons (`$BOOK/src/content`), DDIA, Alex Xu (`~/Desktop/Chinmay/Books/SYstemDesign/alex-xu - part 1 book /chapters1/CHAPTER_*.pdf`; read the chapter for the subject if there is one) and any Hello Interview PDF the user points to in `~/Downloads`. Use them for coverage and for checking against. Never copy passages, diagrams or a chapter's step-by-step solution. Wording, structure and figures are original.
- **Accuracy.** Name real products only where you can defend them (Kafka, ScyllaDB, Redis, APNs/FCM, Envoy, S3). Cite claims about real companies. Mark assumptions as illustrative. Don't invent benchmark numbers.
- **Writing.** Plain, complete sentences that explain each thing before naming it. No em dashes anywhere (the render prints the count; it must be 0). Use curly quotes and apostrophes in HTML text.

## Figure rules (the reason the guide reads in 5 seconds)
- Every path is drawn as a box with the **product name on it**: `box(s, x, y, w, h, 'Kafka', 'partitioned by convo', C.orange)`. Interviewers like hearing names.
- Use one `<figure>` per idea: `<div class="ft">Figure · title</div><svg id="x" viewBox="0 0 980 H"></svg><figcaption>`. Then write a matching `{ const s = document.getElementById('x'); defs(s); ... }` block. Numbering is automatic.
- Colours: `C.blue` services, `C.teal` storage, `C.orange` queues and logs, `C.purple` control, `C.yellow` caution, `C.grey` clients and external, `C.green` OK, `C.redsoft` with `stroke: C.red` for failure. Use `zone()` for regions, cells and trust boundaries, `num()` for step circles, `tile()` for number dashboards, `arrow(s, pts, 'a'|'r'|'b'|'p', {label, at, dash})` with right-angle point lists.
- Keep box labels under about 16 characters at w=170. An arrow label needs about 6.6px per character plus 12. Keep text inside the viewBox: render reports clipped text, and the clipped list must be empty.
- Kinds worth having: scope, contracts, rate tiles, entity diagram, hld steps, final numbered architecture, a sequence or timeline for the hardest path, an options comparison, a failure table, a degradation ladder, evolution steps and levels.

## Build and check
```bash
node $SKILL/tools/render.mjs $W/guide.html $W/guide.pdf $W/png
```
- Fix every reported error, empty figure, clipped text and em dash, then render again.
- Look at the PNGs of figures that are new in kind or dense. You don't need to look at every one.
- Look at 2 or 3 PDF pages as images to check page breaks, for example with `pdftoppm -f N -l N -png`, or by screenshotting in puppeteer.
- Copy the PDF to the store path. Report the path, the page count and the figure count.

## After the PDF (only what the user asked for)
- **open**: `open "<pdf>"`.
- **site** / **add to the website** / **lesson**: convert the guide into a native lesson. Don't make a PDF link card; the user rejected that. Follow `reference/site-lesson.md`. The id is the matching `bp-*` or problem id in `curriculum.ts`. Ask only if none fits.
- **publish**: build and push the site (also in `reference/site-lesson.md`). Publishing goes out to the public, so do it only when the user asked for it in this request.
- **video** / **neonboard** / **archboard**: invoke that skill with the PDF path. The video rules still apply: no music, professor narration and the Kokoro voice. A problem guide video runs 25 to 40 minutes.
- **youtube <id>**: add `youtube: '<id>'` to the lesson's `meta`, then publish.

## Boundaries
- Don't touch `src/content/problems-thinking` (another session owns it). Don't `git init` the book.
- On the website repo, commit only `load-bearing/`. Never use `--force`.
- Use `rm` only on build output you made, by full path.
