import {
  Figure, FailureMode, H2, L7Lens, Lead, LevelCompare, Note, Numbers, Probe, Sources, SystemDiagram, Takeaways,
  type LessonMeta,
} from '../../kit'
import frame from './bp-chat/frame.svg'
import scope from './bp-chat/scope.svg'
import contracts from './bp-chat/contracts.svg'
import rates from './bp-chat/rates.svg'
import entities from './bp-chat/entities.svg'
import hld1 from './bp-chat/hld1.svg'
import hld2 from './bp-chat/hld2.svg'
import hld3 from './bp-chat/hld3.svg'
import hld4 from './bp-chat/hld4.svg'
import skew from './bp-chat/skew.svg'
import seq from './bp-chat/seq.svg'
import retry from './bp-chat/retry.svg'
import sync from './bp-chat/sync.svg'
import storm from './bp-chat/storm.svg'
import fanout from './bp-chat/fanout.svg'
import table from './bp-chat/table.svg'
import presence from './bp-chat/presence.svg'
import regions from './bp-chat/regions.svg'
import fail from './bp-chat/fail.svg'
import ladder from './bp-chat/ladder.svg'
import evolve from './bp-chat/evolve.svg'
import levels from './bp-chat/levels.svg'

export const meta: LessonMeta = {
  summary:
    'One-to-one and group messaging for hundreds of millions of people. The hard parts are a fleet of long-lived connections, one order per conversation, and never losing a message the server has acknowledged.',
  minutes: 35,
  buildsOn: ['delivery-semantics', 'idempotency', 'time-and-order', 'fanout-strategies', 'queue-vs-log', 'l4-l7-balancing', 'metastable-failures', 'partitioning-strategies'],
}

const DECISIONS: [string, [string, string][], string][] = [
  ['Contracts before boxes', [['requirements-as-contracts', 'Requirements as contracts'], ['framing-ambiguity', 'Framing an ambiguous problem']], 'Ch. 1'],
  ['Size the fleet by connections and heartbeats', [['estimation', 'Estimation that changes a decision'], ['server-concurrency', 'How one server handles many requests']], 'Ch. 1'],
  ['Layer-4 balancing of long-lived sockets', [['l4-l7-balancing', 'L4 and L7 load balancing'], ['balancing-algorithms', 'Balancing algorithms that hold up under load']], ''],
  ['Acknowledge after a replicated log write', [['queue-vs-log', 'Queue or log'], ['total-order-broadcast', 'Total order broadcast and the replicated log']], 'Ch. 9, 11'],
  ['A sequence per conversation, not timestamps', [['time-and-order', 'Time, clocks and ordering'], ['id-generation', 'Generating IDs across a fleet']], 'Ch. 8, 9'],
  ['At-least-once delivery, exactly-once display', [['delivery-semantics', 'At-least-once and the exactly-once myth'], ['idempotency', 'Idempotency from end to end']], 'Ch. 11, 12'],
  ['Inbox and cursor per device', [['session-guarantees', 'Read-your-writes, monotonic reads and consistent prefix'], ['derived-data', 'Systems of record and derived data']], 'Ch. 5, 11'],
  ['Persist and deliver as separate consumers', [['outbox-and-cdc', 'The outbox pattern and change data capture'], ['consumer-lag', 'Consumer lag as a health signal']], 'Ch. 11'],
  ['Write fanout for groups, read fanout for channels', [['fanout-strategies', 'Fanout strategies'], ['hot-keys', 'Hot keys and skew']], 'Ch. 1'],
  ['Partition by conversation and time bucket', [['partitioning-strategies', 'Hash, range and directory partitioning'], ['nonrelational-families', 'Document, key-value and wide-column stores']], 'Ch. 6'],
  ['A wide-column store, and tombstones', [['lsm-anatomy', 'Anatomy of an LSM-tree'], ['compaction-strategies', 'Compaction strategies'], ['deletion-semantics', 'Soft deletes, hard deletes and tombstones']], 'Ch. 3'],
  ['Jittered reconnects and admission control', [['deadlines-and-retries', 'Deadlines, retries and retry storms'], ['metastable-failures', 'Metastable failures'], ['overload-control', 'Backpressure, shedding and admission control']], ''],
  ['A home region per conversation', [['active-active', 'Active-passive and active-active'], ['data-residency', 'Data residency and sovereignty'], ['region-evacuation', 'Evacuating a region']], 'Ch. 5'],
  ['A degradation order and cells', [['failure-domains', 'Failure domains and blast radius'], ['cell-architecture', 'Cell-based architecture']], ''],
  ['Gateways, presence and typing (lessons coming)', [['realtime-transports', 'WebSockets, SSE and long polling'], ['connection-fleets', 'Running a fleet of persistent connections'], ['presence', 'Presence and typing indicators']], ''],
]

/** A static diagram exported from the guide's drawings. */
function Pic({ src, title, caption, alt }: { src: string; title: string; caption?: string; alt: string }) {
  return (
    <Figure title={title} caption={caption}>
      <div style={{ background: '#fff', borderRadius: 10, padding: 8 }}>
        <img src={src} alt={alt} style={{ display: 'block', width: '100%', height: 'auto' }} loading="lazy" />
      </div>
    </Figure>
  )
}

/** A plain table in the kit's matrix style. The first column is a row header. */
function Table({ head, rows }: { head: string[]; rows: string[][] }) {
  return (
    <div className="fig" style={{ padding: 0 }}>
      <div className="table-scroll">
        <table className="matrix">
          <thead><tr>{head.map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r[0]}>
                <th>{r[0]}</th>
                {r.slice(1).map((c, i) => <td key={i}>{c}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default function ChatBlueprint() {
  return (
    <>
      <Lead>
        “Design WhatsApp” is one of the most common system design questions. Most answers draw WebSocket servers, a database and push
        notifications, and stop. An L7 answer names the hard parts first: keeping a hundred million or more connections open, getting every
        member of a conversation to see the same order, and never losing a message the server has said it received. Storage is large but well
        understood. This blueprint follows the standard interview framework and builds the design one requirement at a time.
      </Lead>

      <H2>The framework, and what changes at L7</H2>
      <p>
        Use the familiar order, because interviewers can follow it: requirements, core entities, API, a high-level design built one requirement
        at a time, then deep dives. Every level uses the same steps. What changes at L7 is what you put in each one, and how much of the
        steering you do yourself.
      </p>
      <Pic
        src={frame}
        title="The delivery framework, with the L7 addition under each step"
        alt="Six steps: requirements, estimate, entities and API, design, deep dives, close, each with what L7 adds."
        caption="Illustrative minutes for a 45-minute round. Spend less time on the steps everyone gets right and more on the ones that separate levels."
      />
      <Note title="The first ninety seconds, said out loud">
        “I’ll treat this as a consumer chat app with one-to-one and group conversations, on phones and laptops, at roughly WhatsApp or Messenger
        scale. The hard parts are keeping a hundred million or more connections open, getting every member of a conversation to see the same
        order, and never losing a message the server has acknowledged. I’ll keep voice, video and end-to-end encryption out of scope unless you
        want them, because encryption changes what the server is allowed to see. If this is an internal tool for ten thousand employees, most of
        the fleet work disappears, so tell me if I’ve misread the scope.”
      </Note>

      <H2>Requirements: what’s in, and what’s parked</H2>
      <p>
        Pick three or four core features and say the rest out loud as “below the line”. Naming them shows product sense. Parking them keeps the
        design finishable in the time you have.
      </p>
      <Pic
        src={scope}
        title="Above the line we design. Below the line we name and park."
        alt="Four core features above the line, eight parked features below it."
        caption="If the interviewer moves a parked item up, the design changes in a way you can predict. Encryption is the biggest: it removes server-side search and moderation, and multiplies fanout by devices."
      />
      <Table
        head={['Core feature', 'What it means precisely', 'What it forces in the design']}
        rows={[
          ['1. One-to-one messages', 'A sends text to B. B sees it within a second if online.', 'Persistent connections, a registry of who is connected where, and a durable write before “sent”.'],
          ['2. Offline and multi-device', 'B gets everything sent while away, on every device, in order, with no gaps or duplicates.', 'Per-device sync cursors, push notifications, and history stored on the server.'],
          ['3. Group conversations', 'Up to 1,000 members (illustrative). Everyone sees the same order.', 'An ordering authority per conversation, and a fanout strategy that depends on group size.'],
          ['4. Receipts', 'Sent, delivered and read states per message.', 'Acknowledgements as cursors, not per-message rows, or receipt traffic will exceed message traffic.'],
        ]}
      />

      <H2>Non-functional requirements as contracts</H2>
      <p>
        A contract says what’s measured, the target, and the conditions. “Real-time and highly available” is a wish. Split the contracts between
        the message path and the connection fleet, because they fail differently.
      </p>
      <Pic
        src={contracts}
        title="The headline contracts"
        alt="Six contract cards: 500 ms delivery, zero acked messages lost, one order per conversation, displayed once, 2 minute reconnect, 5 second sync."
        caption="Illustrative targets. The ordering and duplicate contracts are the ones most candidates leave out, and the deep dives depend on them."
      />
      <Table
        head={['Contract', 'Target (illustrative)', 'Why that number, and what it costs']}
        rows={[
          ['Online delivery latency', 'p99 under 500 ms in one region, under 1 s across regions.', 'Feels instant in a conversation. Cross-region adds one long network hop you can’t remove.'],
          ['Durability', 'Once the sender sees “sent”, the message survives losing a zone.', 'Decides the order of operations: acknowledge after a replicated log write, never before.'],
          ['Ordering', 'Every member sees one order within a conversation. No order across conversations.', 'A single sequencing point per conversation. A global order would be a bottleneck nobody needs.'],
          ['Duplicates', 'Delivery is at least once. Display is exactly once.', 'Client-generated message IDs and deduplication on both ends.'],
          ['Offline sync', 'A device back after 30 days gets every missed message in order, in under 5 s for typical backlogs.', 'A per-user change log with cursors, not a scan of every conversation.'],
          ['Send availability', '99.99% of sends succeed, measured at the client.', 'About 4 minutes a month. Rules out single-region designs for the send path.'],
          ['Reconnect', 'After losing a zone of gateways, affected clients are back within 2 minutes without overloading anything.', 'Forces jittered backoff on clients and headroom on gateways.'],
          ['Retention and deletion', 'Deletion visible everywhere in 1 minute, purged within 30 days.', 'Deletion is a write that fans out, plus a background purge for storage and backups.'],
        ]}
      />

      <H2>Numbers that decide the design</H2>
      <p>
        Assume 500 million daily active users, each sending about 40 messages a day, with 30% online at the daily peak. These are invented
        assumptions to state out loud. Every number below should end in a decision.
      </p>
      <Numbers
        items={[
          { value: '700K/s', label: 'messages at peak', note: '20 billion a day, 3× the average at peak' },
          { value: '150M', label: 'open sockets', note: '30% of 500M users online at once' },
          { value: '2,250', label: 'gateway hosts', note: '100K connections each, plus headroom to lose a zone' },
          { value: '5M/s', label: 'heartbeats', note: 'one every 30 s per socket: 7× the message rate' },
        ]}
      />
      <p>
        Storage comes to about 20 billion messages × 250 bytes ≈ 5 TB a day, or 15 TB with three replicas. The session registry is about 150
        million entries × 100 bytes ≈ 15 GB, which fits one Redis cluster. For scale, WhatsApp wrote in 2012 that a heavily tuned server held more
        than two million connections. A planning number should be far lower and leave room for TLS, deploys and losing a zone.
      </p>
      <Pic
        src={rates}
        title="Per-second rates at the daily peak"
        alt="Log-scale bars: presence to open screens 290K, messages 700K, deliveries 1.4M, heartbeats 5M, presence to all contacts 11.6M per second."
        caption="Log scale, computed from the assumptions above. Presence is shown both ways: pushed to every contact, and sent only to people with that chat open."
      />
      <L7Lens title="What the numbers say">
        The busiest thing in a chat system isn’t messages. It’s idle connections saying “still here”, and presence updates if you’re careless. So
        heartbeats must be answered by the gateway itself, never by a backend, and the fleet is sized by connections and memory rather than by
        message throughput. Storage is large but it’s an append-only workload with a known partition key, which is exactly what wide-column stores
        are for.
      </L7Lens>

      <H2>Core entities and the API</H2>
      <p>
        Keep this short in the room: a list of entities and a few calls. Two details deserve a sentence each, the sequence number and the client
        message ID, because the deep dives depend on them.
      </p>
      <Pic
        src={entities}
        title="Seven entities, and the keys that matter"
        alt="User, Device, Conversation, Member, Message, Cursor and Inbox entry, with their key fields."
        caption="Bold fields are keys. A message is identified by (conversation, sequence). The client message ID is the deduplication key for retries."
      />
      <p>Over the WebSocket:</p>
      <pre style={{ overflowX: 'auto' }}><code>{`→ send      {client_msg_id, conversation_id, body | media_ref}
← ack       {client_msg_id, seq, server_ts}      the message is durable: show "sent"
← deliver   {conversation_id, seq, sender_id, body, server_ts}
→ delivered {conversation_id, up_to_seq}
→ read      {conversation_id, up_to_seq}
← receipt   {conversation_id, user_id, delivered_seq, read_seq}`}</code></pre>
      <p>Over HTTPS:</p>
      <pre style={{ overflowX: 'auto' }}><code>{`GET  /sync?inbox_cursor=8812                        changes since the cursor
GET  /conversations/{id}/messages?before_seq=500    older history, page by page
POST /conversations {member_ids}                    a new conversation
POST /media                                         a signed upload URL`}</code></pre>
      <Note title="Security in the API">
        The sender’s user ID comes from the authenticated session, never from the message body. The server sets the timestamp and the sequence
        number. The client message ID is the only identifier the client chooses, and it’s only used to recognise retries from the same sender.
      </Note>

      <H2>Build it one requirement at a time</H2>
      <p>
        Start with the simplest thing that satisfies requirement 1, then let each new requirement force the next piece. The interviewer sees why
        each box exists, and you never draw a box you can’t justify.
      </p>
      <Pic
        src={hld1}
        title="Step 1: one-to-one messages, both people online"
        alt="Alice, a layer-4 balancer, a gateway, a chat service writing to a message store, a session registry, and Bob's gateway."
        caption="Gateways hold WebSockets and are stateful, so the balancer works at layer 4 and the session registry records which gateway each device is on."
      />
      <p>
        Alice’s phone keeps a WebSocket open to a gateway. The chat service assigns the next sequence number for the conversation, writes the
        message, acknowledges Alice, looks up Bob’s devices in the session registry, and forwards the message to Bob’s gateway. <b>What’s wrong
        with it:</b> the chat service stores and then forwards. If it crashes between the two, Bob never gets the message, and if Bob is offline
        there’s nowhere for it to wait.
      </p>
      <Pic
        src={hld2}
        title="Step 2: offline users and multiple devices. A commit log decides what “sent” means."
        alt="Kafka added after the chat service, with a persister to ScyllaDB, fanout workers, per-user inboxes and push notifications."
        caption="The acknowledgement to Alice now happens after the Kafka write. Two independent consumers persist and deliver, so a crash in either is retried from the log rather than losing the message."
      />
      <p>
        The chat service appends the message to Kafka, partitioned by conversation ID, and acknowledges Alice once the write is replicated. A
        persister writes it to ScyllaDB. Fanout workers append a pointer to each recipient’s inbox, a per-user change log, and push to any
        connected device. Devices with no connection get a push notification through APNs or FCM, and when they come back they ask “what changed
        since my inbox cursor?”
      </p>
      <Pic
        src={hld3}
        title="Step 3: group conversations. Membership drives fanout."
        alt="Users and groups in Postgres added, read by the fanout workers."
        caption="Nothing about ordering changes: a group is a conversation with more members. What changes is how many inboxes one message touches."
      />
      <Pic
        src={hld4}
        title="Step 4: receipts are cursors, presence is a TTL"
        alt="A presence store in Redis added next to Bob's gateway."
        caption="A device acknowledges “delivered up to sequence 42”, not each message. Presence is a key with a short time-to-live, refreshed by the gateway while the socket is alive."
      />

      <H2>The whole design, one message at a time</H2>
      <SystemDiagram
        title="The final design: follow one message from Alice to Bob"
        caption="Press play to follow a message. Products are examples you could defend, not the only choices. Media never goes through the chat path. On reconnect, a device calls sync, which reads its inbox and the message store (not drawn)."
        width={1200}
        height={540}
        nodes={[
          { id: 'alice', label: 'Alice', sub: 'phone', kind: 'client', x: 20, y: 40 },
          { id: 'lb', label: 'L4 balancer', sub: 'NLB or Envoy', kind: 'lb', x: 220, y: 40 },
          { id: 'gw', label: 'Gateway', sub: 'WebSocket', kind: 'edge', x: 420, y: 40 },
          { id: 'chat', label: 'Chat service', sub: 'seq, dedupe', kind: 'service', x: 620, y: 40 },
          { id: 'kafka', label: 'Kafka', sub: 'by conversation', kind: 'queue', x: 820, y: 40 },
          { id: 'msgs', label: 'Messages', sub: 'ScyllaDB', kind: 'db', x: 1016, y: 40 },
          { id: 'sess', label: 'Sessions', sub: 'Redis', kind: 'cache', x: 620, y: 180 },
          { id: 'fan', label: 'Fanout', sub: 'workers', kind: 'worker', x: 820, y: 180 },
          { id: 'inbox', label: 'Inboxes', sub: 'per-user log', kind: 'db', x: 1016, y: 180 },
          { id: 'bob', label: 'Bob', sub: 'phone, laptop', kind: 'client', x: 20, y: 320 },
          { id: 'gwb', label: 'Gateway', sub: 'Bob’s socket', kind: 'edge', x: 420, y: 320 },
          { id: 'push', label: 'Push', sub: 'APNs, FCM', kind: 'external', x: 820, y: 320 },
          { id: 'groups', label: 'Users, groups', sub: 'Postgres', kind: 'db', x: 1016, y: 320 },
          { id: 'media', label: 'Media API', sub: 'signed URLs', kind: 'service', x: 620, y: 450 },
          { id: 's3', label: 'Media', sub: 'S3 and a CDN', kind: 'storage', x: 1016, y: 450 },
        ]}
        edges={[
          { from: 'alice', to: 'lb' },
          { from: 'lb', to: 'gw' },
          { from: 'gw', to: 'chat' },
          { from: 'chat', to: 'kafka' },
          { from: 'kafka', to: 'msgs' },
          { from: 'kafka', to: 'fan' },
          { from: 'fan', to: 'inbox' },
          { from: 'fan', to: 'sess' },
          { from: 'fan', to: 'groups' },
          { id: 'deliver', from: 'fan', to: 'gwb', fromSide: 'bottom', toSide: 'top', fromOffset: -40 },
          { from: 'gwb', to: 'bob' },
          { from: 'fan', to: 'push', fromOffset: 30 },
          { id: 'wake', from: 'push', to: 'bob', style: 'async', fromSide: 'bottom', toSide: 'bottom' },
          { id: 'upload', from: 'lb', to: 'media', fromSide: 'bottom', toSide: 'left' },
          { from: 'media', to: 's3' },
        ]}
        steps={[
          { title: 'Connect', body: 'Alice’s phone holds a TLS WebSocket through a layer-4 balancer. The gateway authenticates once, at connect time, and answers heartbeats itself.', edges: ['alice>lb', 'lb>gw'] },
          { title: 'Send', body: 'Alice sends {client_msg_id, conversation, body}. The gateway applies per-user rate limits and passes it on.', edges: ['gw>chat'] },
          { title: 'Sequence and make durable', body: 'The chat service checks membership, drops retries it has already seen, assigns the next sequence number, and appends to Kafka. Alice gets “sent” only after the write is replicated.', edges: ['chat>kafka'] },
          { title: 'Persist', body: 'A persister writes the message to ScyllaDB, partitioned by conversation and time bucket, sorted by sequence.', edges: ['kafka>msgs'] },
          { title: 'Fan out', body: 'Fanout workers read the member list and append one inbox pointer per recipient. The body is stored once.', edges: ['kafka>fan', 'fan>groups', 'fan>inbox'] },
          { title: 'Find live devices', body: 'The session registry says which gateway each of Bob’s devices is on.', edges: ['fan>sess'] },
          { title: 'Deliver live', body: 'Connected devices get the message down their socket and acknowledge “delivered up to sequence 42”.', edges: ['deliver', 'gwb>bob'] },
          { title: 'Wake the offline device', body: 'Devices with no socket get a push through APNs or FCM. When the app opens, it syncs from its inbox cursor.', edges: ['fan>push', 'wake'] },
          { title: 'Media stays off the chat path', body: 'Photos and files upload straight to object storage with a signed URL. The message carries only a reference.', edges: ['upload', 'media>s3'] },
        ]}
      />
      <Table
        head={['Role', 'Name to say', 'The property you need, and an alternative']}
        rows={[
          ['Layer-4 balancer', 'AWS NLB, or Envoy in TCP mode', 'Long-lived connections, no per-request parsing. An L7 balancer works but adds a hop that holds every socket.'],
          ['Gateway', 'A custom Go or Erlang service', 'Millions of mostly idle sockets and cheap heartbeats. WhatsApp famously used Erlang.'],
          ['Commit log', 'Kafka', 'Replicated, ordered within a partition, readable by several consumers independently. Pulsar or Kinesis are alternatives.'],
          ['Message store', 'ScyllaDB or Cassandra', 'Huge append-only writes on a known partition key, with time-ordered reads. Discord moved from Cassandra to ScyllaDB.'],
          ['Sessions, presence', 'Redis', 'Fast keys with time-to-live. Losing it is survivable, because devices re-register on their next heartbeat.'],
          ['Users, groups', 'Postgres', 'Small, relational, needs transactions for membership changes.'],
          ['Push', 'APNs and FCM', 'The only way to wake a sleeping phone. Treat them as dependencies with their own failure budget.'],
          ['Media', 'S3 and a CDN', 'Large blobs stay off the chat path. Signed URLs keep them private.'],
        ]}
      />
      <Note title="How to name a product out loud">
        “I’m putting Kafka between the chat service and everything else because I need one durable point where a message becomes ‘sent’. After
        that, storing it and delivering it are two independent consumers that can each fail and retry without losing anything.” Role, product, the
        property you need, and the fact that it’s replaceable.
      </Note>

      <H2>Deep dive: ordering and message IDs</H2>
      <p>
        The contract says every member sees the same order within a conversation. The obvious approach, sorting by timestamp, fails in a way
        users notice immediately: replies appear above the questions they answer.
      </p>
      <Pic
        src={skew}
        title="Why timestamps aren’t an order"
        alt="Two servers, one 300 ms slow. Bob's reply gets an earlier timestamp than Alice's question, so a timestamp sort puts the answer first."
        caption="Illustrative clocks. A sequence number from one owner can’t be inverted this way."
      />
      <Table
        head={['Option', 'How it works', 'Verdict']}
        rows={[
          ['Client timestamp', 'The phone stamps the message.', 'Phone clocks are wrong by minutes, and users can change them. Never use it for order.'],
          ['Server timestamp', 'Whichever server receives it stamps it.', 'Clock skew between servers reorders close messages.'],
          ['Snowflake-style ID', 'Time bits, machine bits and a counter, unique across the fleet.', 'Unique and roughly time-ordered, but still skew-prone, and it has gaps, so clients can’t detect missing messages.'],
          ['Sequence per conversation', 'One owner per conversation hands out 1, 2, 3.', 'Use this. Total order within the conversation, and gaps reveal missing messages.'],
        ]}
      />
      <p>
        Route every send for a conversation to the same place. The cleanest way is to let Kafka’s partition do it: the chat service instance that
        owns a partition handles every conversation hashing to it, and keeps their counters in memory, recovered from the log after a crash.
        Alternatives are a Redis INCR per conversation, which is fast but is a second system that must not lose state, or a lightweight
        transaction in Cassandra, which is correct but slow under contention in busy groups.
      </p>
      <L7Lens title="Scope the guarantee">
        Say plainly that there’s no order across conversations, and that’s fine because nobody can see it. Total order is expensive, so you buy it
        only where users can tell the difference. That sentence shows you know what ordering costs.
      </L7Lens>

      <H2>Deep dive: delivery, acknowledgements and sync</H2>
      <p>
        Networks drop packets and phones lose signal in elevators. Exactly-once delivery isn’t possible over a network that can lose
        acknowledgements. What you can build is at-least-once delivery with exactly-once display.
      </p>
      <Pic
        src={seq}
        title="One message, three acknowledgements"
        alt="A sequence diagram from Alice's app through gateway, chat service, Kafka and fanout to Bob's app, with sent, delivered and read acknowledgements."
        caption="“Sent” means durable on the server. “Delivered” means a device has it. “Read” means a person has seen it. Receipts travel as cursors, so one update covers many messages."
      />
      <Pic
        src={retry}
        title="A retry that doesn’t create a duplicate"
        alt="Four panels: send, the ack is lost, the client retries with the same ID, the server recognises it and returns the same sequence number."
        caption="The client keeps the message in a local outbox until it sees an ack. The server remembers recent client message IDs per sender, for example for 24 hours."
      />
      <p>
        Each user has an <b>inbox</b>: an ordered log of “conversation C has a new message at sequence S”. Each device keeps its own cursor into it,
        so reconnecting is one query. Quiet conversations never appear in the log, so sync cost follows activity rather than how many chats you’re
        in. Facebook described the same shape for Messenger in 2014: a per-user ordered queue of updates, with each device tracking its position.
        Because sequences are dense, a client holding messages 40 and 42 knows 41 is missing and fetches it.
      </p>
      <Pic
        src={sync}
        title="One inbox, a cursor per device"
        alt="Inbox entries 101 to 108. The phone cursor is at 108, the laptop cursor at 103, and the laptop fetches 104 to 108."
        caption="Illustrative positions. Old inbox entries are compacted once every device has passed them."
      />

      <H2>Deep dive: the connection fleet</H2>
      <p>
        A stateless web fleet can be deployed or scaled at will. A gateway fleet can’t: every host holds a hundred thousand people’s live sockets.
        WebSockets fit chat because sends, receipts and typing all travel upstream on the same connection. Long polling is a fallback behind strict
        proxies, and server-sent events suit read-only feeds.
      </p>
      <p>
        When a gateway dies or a deploy restarts it, its clients reconnect at once. If they retry on a fixed schedule they arrive in waves, and
        each wave can knock over the next gateway. The system stays broken after the original cause is gone, which is a metastable failure.
      </p>
      <Pic
        src={storm}
        title="300,000 clients reconnecting after losing 3 gateways"
        alt="Line chart: with backoff and full jitter, 99% reconnect by 84 seconds. With fixed 5 second retries, only 19% are back after 2 minutes."
        caption="Illustrative simulation with a seeded random generator. Fixed retries keep arriving above what the fleet can accept. Jittered backoff spreads the same clients under the limit."
      />
      <FailureMode
        title="The reconnect storm"
        trigger="A deploy restarts gateways, or a zone of gateways fails, and every disconnected client retries on the same schedule."
        symptom="Logins fail in waves. Each wave overloads the next gateways, so the outage outlasts its cause."
        contain="Exponential backoff with full jitter in the mobile app, a server-sent retry-after hint, per-host admission control on new connections, headroom for a zone, and deploys that drain over minutes instead of killing sockets."
      />
      <Note title="Heartbeats and battery">
        Mobile networks drop idle connections, so clients send heartbeats. Too frequent wastes battery and costs millions of packets per second. Too
        rare and NAT devices silently drop the socket. Pick the interval from measured timeouts, and let the gateway answer heartbeats without any
        backend. Long-lived connections also don’t rebalance on their own, so after a deploy new hosts sit empty: use connection caps and slow,
        deliberate draining.
      </Note>

      <H2>Deep dive: group fanout and storage</H2>
      <Pic
        src={fanout}
        title="Small groups copy pointers out. Large channels let members read."
        alt="Left: a message copied as a pointer into four members' inboxes. Right: one channel log, with only members viewing now getting a live push."
        caption="The message body is stored once in both models. Treat the threshold as a setting you tune, not a constant."
      />
      <Table
        head={['', 'Write fanout (push to inboxes)', 'Read fanout (members read the conversation)']}
        rows={[
          ['Send cost', 'One inbox write per member.', 'One write.'],
          ['Sync cost', 'One query per device: my inbox.', 'Check every large channel I’m in.'],
          ['Fits', 'One-to-one and groups up to a few hundred or a thousand.', 'Channels with tens of thousands of members, like Slack or Discord servers.'],
          ['L7 choice', 'Hybrid by size. Live delivery to connected members is the same in both.', 'Large channels also get per-channel rate limits, so one busy channel can’t flood every member.'],
        ]}
      />
      <Pic
        src={table}
        title="Partition by conversation and time bucket, sort by sequence"
        alt="Three partitions of conversation 88, one per month, each sorted newest first."
        caption="Bucketing bounds partition size, so a ten-year-old busy channel doesn’t become one enormous partition. Discord described bucketing by channel and time window in 2017."
      />
      <p>
        A wide-column store fits because writes are appends, reads are “the latest 50 in this conversation”, and the partition key is always known:
        an LSM-tree’s best case. Two things to plan for: a viral channel concentrates writes on one partition, and deletes leave tombstones that slow
        reads until compaction removes them. Discord’s 2017 post describes exactly that tombstone problem.
      </p>

      <H2>Deep dive: presence, typing and regions</H2>
      <p>
        The naive design pushes every status change to every contact. A user with 200 contacts who opens and closes the app 10 times a day creates
        4,000 pushes, and across 500 million users that’s about 11.6 million a second, more than the messages themselves.
      </p>
      <Pic
        src={presence}
        title="Presence updates per second, three designs"
        alt="Bars: push to all contacts 11.6M per second, messages 700K, open screens only 290K."
        caption="Computed from the assumptions above, with about 5 viewers per change when presence goes only to open screens. Illustrative, but the order of magnitude is the point."
      />
      <ul>
        <li><b>Lazy subscription:</b> a client subscribes to presence only for conversations on screen.</li>
        <li><b>Heartbeat with time-to-live:</b> the gateway refreshes a Redis key while the socket is alive. If it expires the user is offline, so a crashed phone still goes offline.</li>
        <li><b>Coarse and delayed:</b> “last seen a few minutes ago” is cheaper than second-by-second accuracy, and kinder to privacy.</li>
        <li><b>Typing indicators</b> are never stored, expire quickly, and are the first thing dropped under load.</li>
      </ul>
      <Pic
        src={regions}
        title="Each conversation has a home region"
        alt="Bob in the US region sends to conversation 88, whose home is the EU region. The EU chat service numbers it, then it is delivered back to the US gateway."
        caption="Users connect to the nearest region. Sends are forwarded to the conversation’s home region, where its sequence is assigned. Only one region numbers a conversation, so ordering holds without global consensus."
      />
      <L7Lens title="If the interviewer adds end-to-end encryption">
        The server stores and forwards ciphertext it can’t read. Search moves to the device, moderation works from user reports, and push
        notifications can’t show content unless the device decrypts them. With multiple devices the sender encrypts once per recipient device, as in
        Signal’s Sesame design, so fanout multiplies by devices. These consequences change scope, cost and the trust and safety team’s tools.
      </L7Lens>

      <H2>Failures, degradation and evolution</H2>
      <Pic
        src={fail}
        title="What fails, what users see, what contains it"
        alt="Five failures: a gateway dies, a reconnect storm, a Kafka leader moves, the session registry is lost, push providers degrade."
        caption="Green rows are contained by design. Yellow rows are noticed by users, but nothing is lost."
      />
      <FailureMode
        title="The session registry loses its data"
        trigger="The Redis cluster that maps devices to gateways restarts empty."
        symptom="For about a minute, fanout can’t find live sockets, so connected users get push notifications instead of instant delivery."
        contain="Treat the registry as a cache: gateways re-register every device on its next heartbeat, and messages are safe in Kafka and the inboxes the whole time."
      />
      <Pic
        src={ladder}
        title="The degradation ladder: what is shed first, and what never is"
        alt="Typing indicators shed first, then presence, read receipts, history, and send and deliver never shed."
        caption="Decide this order in advance and build switches for it. During an incident, a system without a plan sheds whatever breaks first, which is often sending."
      />
      <Pic
        src={evolve}
        title="Build each step only when its trigger shows up"
        alt="Five steps: one region with groups, read-fanout channels, a second region, cells per region, end-to-end encryption, each with its trigger."
      />
      <p>
        <b>Who has to change.</b> The mobile team owns reconnect behaviour, heartbeat intervals, local outboxes and gap detection: half of this
        design runs on the phone. Trust and safety owns spam and abuse limits. Legal and privacy own retention and deletion rules per country, which
        decide where a conversation can have its home region. Publish cost per thousand monthly users, so product teams see what features like
        presence and large channels cost.
      </p>
      <LevelCompare
        question="“Design WhatsApp.”"
        l5="WebSocket servers, a database, a cache and push notifications, with messages sorted by timestamp."
        l6="Adds a session registry, Kafka, a wide-column store, per-device sync and presence with heartbeats."
        l7="Frames it as a connection-fleet and ordering problem, writes contracts for durability, order and duplicates, chooses the deep dives, plans reconnect storms and fanout by group size, and names who must change: mobile, trust and safety, legal."
      />

      <H2>What each level is expected to show</H2>
      <Pic
        src={levels}
        title="Breadth and depth by level"
        alt="Bars from mid-level at 80% breadth to principal at 40% breadth and 60% depth."
        caption="Rough proportions of interview time, not a scoring rule."
      />
      <Table
        head={['Level', 'The bar for this problem', 'Common reason for a down-level']}
        rows={[
          ['Mid-level', 'A working design for one-to-one and groups: WebSockets, a registry, a store, push, and a clear API and data model.', 'Stateless chat servers behind an HTTP balancer, with no idea where a recipient is connected.'],
          ['Senior', 'Moves through the basics quickly, then goes deep on two of: ordering, offline sync, group fanout.', 'Timestamp ordering, or “exactly-once delivery” without saying how.'],
          ['Staff', 'Three or more deep dives chosen without prompting, including reconnect storms and multiple regions.', 'Never mentions the fleet’s failure modes, or treats presence as free.'],
          ['Principal', 'Everything at staff, plus contracts that drive the design, a degradation order, evolution triggers, cost and the teams that must change.', 'A perfect architecture with no opinion on what to build first, what to shed, or who owns the phone side.'],
        ]}
      />

      <H2>Corrections to common notes</H2>
      <Table
        head={['Claim', 'Correction']}
        rows={[
          ['“Order messages by timestamp.”', 'Clocks skew between servers and phones. Use a sequence number per conversation from one owner.'],
          ['“Chat servers are stateless, so any balancer works.”', 'Gateways hold live sockets, so they’re stateful. Balance at layer 4, keep a session registry, and drain deliberately.'],
          ['“Guarantee exactly-once delivery.”', 'Not possible over a lossy network. Deliver at least once and deduplicate by client message ID.'],
          ['“Send each presence change to every friend.”', 'That’s millions of updates a second at scale. Subscribe lazily and let keys expire.'],
          ['“Copy each group message into every member’s inbox.”', 'Fine for small groups. Large channels need read fanout.'],
          ['“Acknowledge once the chat server receives it.”', 'Acknowledge after a replicated write, or a crash loses a message the user believes was sent.'],
        ]}
      />

      <H2>Where each decision comes from</H2>
      <p>
        This blueprint doesn’t introduce new mechanisms. Every decision above is a lesson from earlier in the book, applied to one product. The
        third column points to the matching chapter of <i>Designing Data-Intensive Applications</i> (first edition) for further reading.
      </p>
      <div className="fig" style={{ padding: 0 }}>
        <div className="table-scroll">
          <table className="matrix">
            <thead><tr><th>Decision in this design</th><th>Lessons it applies</th><th>Further reading</th></tr></thead>
            <tbody>
              {DECISIONS.map(([d, lessons, ddia]) => (
                <tr key={d}>
                  <th>{d}</th>
                  <td>{lessons.map(([id, t], i) => <span key={id}>{i > 0 && ', '}<a href={`#/lesson/${id}`}>{t}</a></span>)}</td>
                  <td>{ddia}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <H2>Test yourself</H2>
      <Probe question="A celebrity creates a channel with 2 million members. What changes?">
        Switch it to read fanout, rate-limit sends to the channel, push live only to members who are connected and viewing, and give it its own
        Kafka partitions so it can’t delay normal conversations. At that size it’s really a broadcast product, so ask whether replies should be
        allowed at all.
      </Probe>
      <Probe question="Bob says he never got a message Alice says she sent. How do you find out where it went?">
        Walk the acknowledgements. Did Alice’s client get “sent” with a sequence number? Is the message in the store? Did Bob’s inbox get the
        pointer? Did any device acknowledge delivery? Each answer narrows it to one component, which is possible only because the acks are distinct
        promises.
      </Probe>
      <Probe question="Can we drop Kafka and write straight to ScyllaDB?">
        Yes, if you acknowledge after the database write and deliver from a change stream or an outbox table. You lose a clean replay point, and
        delivery then depends on database health. It’s a fair tradeoff at smaller scale. For 5,000 employees, one region, a few gateways and
        Postgres for messages is the right answer, and saying so is a strong signal.
      </Probe>

      <Takeaways
        items={[
          'Name the hard parts first: a fleet of long-lived connections, one order per conversation, and no lost acknowledged messages.',
          'Acknowledge “sent” only after a replicated log write. Then persisting and delivering are independent consumers that can retry.',
          'Order with a sequence number per conversation from one owner, never with timestamps. Gaps tell clients what to fetch.',
          'Deliver at least once and display exactly once, using client message IDs. Receipts and sync are cursors.',
          'Size the fleet by connections and heartbeats, design for reconnect storms, and make presence lazy.',
          'Fan out by group size, and name who must change: the mobile team, trust and safety, and legal.',
        ]}
      />
      <Sources
        items={[
          { title: '1 million is so 2011', url: 'https://blog.whatsapp.com/1-million-is-so-2011', note: 'WhatsApp, 2012: more than two million connections on one tuned server' },
          { title: 'Building Mobile-First Infrastructure for Messenger', url: 'https://engineering.fb.com/2014/10/09/production-engineering/building-mobile-first-infrastructure-for-messenger/', note: 'Facebook, 2014: a per-user ordered queue of updates with a position per device' },
          { title: 'How Discord Stores Billions of Messages', url: 'https://discord.com/blog/how-discord-stores-billions-of-messages', note: 'Discord, 2017: Cassandra, channel and time buckets, tombstones' },
          { title: 'How Discord Stores Trillions of Messages', url: 'https://discord.com/blog/how-discord-stores-trillions-of-messages', note: 'Discord, 2023: the move to ScyllaDB' },
          { title: 'Real-time Messaging', url: 'https://slack.engineering/real-time-messaging/', note: 'Slack, 2023: gateway servers for connections, channel servers for channel state' },
          { title: 'Signal technical documentation', url: 'https://signal.org/docs/', note: 'The Double Ratchet and Sesame, for multi-device encryption' },
          { title: 'Exponential Backoff and Jitter', url: 'https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/', note: 'AWS Architecture Blog, 2015' },
          { title: 'RFC 6455: The WebSocket Protocol', url: 'https://www.rfc-editor.org/rfc/rfc6455' },
        ]}
      />
    </>
  )
}
